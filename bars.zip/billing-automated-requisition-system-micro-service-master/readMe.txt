>Login Link

-http://localhost:3070/login

>Bars Link

-http://localhost:8080/

>Default Admin
-username: SuperAdmin
-password: 123456

>Sample User
-username: testuser
-password: 123456

>PORT Configurations
-Client Login - 3070
-Server Login - 3000

-Client BARS - 8080
>Server BARS ports for load balancer
Run Configurations
-5090
-5091
-5092

>Load Balancer and Circuit Breaker implementations 
- http://localhost:8080/upload

>Angular UI
-success.html

>Test Files
-testFile folder in root directory

>Database schema
-Login Microservices
	#barslogin_db.schema.sql

-Bars Microservices
	#barsmicroservices_db_schema.sql



