package com.accenture.bars.microservices.server.renzchler.s.oxino.request;

import org.springframework.data.jpa.repository.JpaRepository;

public interface IRequestRepository extends JpaRepository<Request, Integer>{

}
