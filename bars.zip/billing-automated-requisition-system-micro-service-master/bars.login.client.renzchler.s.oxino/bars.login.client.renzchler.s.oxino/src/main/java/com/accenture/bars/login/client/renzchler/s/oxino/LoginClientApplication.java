package com.accenture.bars.login.client.renzchler.s.oxino;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginClientApplication.class, args);
	}

}
